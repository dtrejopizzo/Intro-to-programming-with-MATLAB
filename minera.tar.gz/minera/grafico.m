% Vector de 300 posiciones entre -pi y pi
x = linspace(-pi,pi,300);

y1 = sin(x);
y2 = cos(x);

plot(x,y1,'-b',x,y2,'-r')
legend('sin(x)','cos(x)')

xlabel('Eje X')
ylabel('Eje Y')
title('Graficos FINAL')
