function prom(mmultas,tam)

consumoTotal=sum(mmultas(:,2));

promConsumo=consumoTotal/tam;

printf('Promedio de consumo es %.2f\n\n',promConsumo);
