function codigo=cargar()

i=1;
valor=input('Ingrese el codigo de una empresa (mayor a cero): ');
if(valor>0)
	codigo(i)=valor;	
	i++;
end
while(valor>0)
	valor=input('Ingrese el codigo de una empresa (mayor a cero): ');
	if(valor>0)
		codigo(i)=valor;	
		i++;
	else
		i--;
	end
end
