clc
clear all

printf('-------------------------------------------\n');
printf('- Calculo de multas para empresas mineras -\n');
printf('-------------------------------------------\n');

% 1) Cargo un vector con codigos de empresas
codigo=cargar();

% 2) Genero una matriz con los codigos de las empresas y sus consumos de
% MM3 de agua.
[consumo,tam]=generoConsumo(codigo);

consumo
tam

% 3) Calculo multas
mmultas=multas(consumo,tam);

printf('\n\nEmpresa - Consumo de agua (mm3) - Multas\n');
mmultas

% 4) Calculo promedios
prom(mmultas,tam);

