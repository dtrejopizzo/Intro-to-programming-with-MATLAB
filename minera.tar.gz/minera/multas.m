function mmultas=multas(consumo,tam)

for i=1:1:tam
	if(consumo(i,2)<=5)
		consumo(i,3)=0;
	elseif(consumo(i,2)>5 && consumo(i,2)<=15)
		consumo(i,3)=100000;
	elseif(consumo(i,2)>15)
		consumo(i,3)= (100000 + (consumo(i,2)-15)*10000);
	end
end

mmultas=consumo;
