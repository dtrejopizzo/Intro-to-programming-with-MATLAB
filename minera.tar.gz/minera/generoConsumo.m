function [consumo,tam]=generoConsumo(codigo)

i=1;

tam=length(codigo);
consumo=zeros(tam,3);
consumo(:,1)=codigo';

for i=1:1:tam
	valor=input('Ingrese el consumo: ');
	consumo(i,2)=valor;
end
