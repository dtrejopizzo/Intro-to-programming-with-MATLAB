function listarPromedioInferior(CALIFICACIONES,promedioNotas,m)

% primedio, busco cual es el promedio de todos los promedios generales
promedioSobrePromedios=mean(promedioNotas)

% Ahora si, listo los docentes cuyo promedio sea inferior al promedio general de todas las notas
for i=1:m
	if(promedioNotas(i)<promedioSobrePromedios)
		docente=CALIFICACIONES(i,1);
		fprintf('El docente: %d tiene un promedio es %.2f, y este esta por debajo de la media de promedios\n',docente,promedioNotas(i));
	end
end
