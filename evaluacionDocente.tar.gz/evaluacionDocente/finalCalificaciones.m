% Final de Calificaciones docentes

clc
clear all

m=input('Ingrese la cantidad de docentes que va a evaluar: ');

% Primero creo una matriz de m filas y 6 columnas, con valores entre 0 y 10
CALIFICACIONES=randi([0 10],m,6);

% Ahora, como la primer fila corresponde a los legajos docentes, la modifico
% con valores enttre 100000 y 200000
CALIFICACIONES(:,1)=randi([100000 200000],m,1)
% CALIFICACIONES(:,1) me sirve para decirle a Octave que voy a tocar la columna
% 1 de la matriz CALIFICACIONES
% En randi([100000 200000],m,1) uso m por las filas que voy a modificar y
% 1 porque solo voy a crear un vector de 1 columna por m filas, y eso es lo que
% voy a guardar en la columna 1 de CALIFICACIONES


% 1) Informar el docente con mejor promedio general

sumaNota=0;

for i=1:m
	notas=CALIFICACIONES(i,2:6); %Extraigo de la fila i, las columnas 2 a las 6 que tienen las notas
	sumaNotas=sum(notas); %Sumo el vector que extraje anteriormente, que son las notas para cada profesor
	sumaCalificaciones(i)=sumaNotas; %En el vector sumaCalificaciones, guardo la suma de notas para cada profesor
	%La primer posicion corresponde al primer profesor, la segunda posicion al segundo profesor y asi...
end

% Muestro el vector donde estan guardadas las sumas de las calificaciones
sumaCalificaciones;

% Genero un vector con los promedios de las notas
for i=1:m
	promedioNotas(i)=sumaCalificaciones(i)/5;
end

% Busco el mayor promedio y la posicion en el vector
[prom,pos]=max(promedioNotas);

% La posicion del valor, corresponde al docente. Si la posicion del mejor promedio es 5, entonces el docente de mejor promedio
% es el 5. Ahora muestro el mejor promedio y a que docente corresponde.

% Para saber cual es el docente, me fijo en la Matriz calificaciones, columna 1 (legajos) y fila (pos)
docente=CALIFICACIONES(pos,1);
fprintf("1) El mejor promedio es %.2f y corresponde al docente de legajo %d.\n\n",prom,docente);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% 2) el mejor docente en cada una de las caracteristicas a evaluar.

%Extraigo las notas de "Trato con alumnos" (columna 2)
notasTrato=CALIFICACIONES(:,2);
%Extraigo la mejor nota y la posicion
[mejorTrato,pos1]=max(notasTrato);
% Para saber cual es el docente, me fijo en la Matriz calificaciones, columna 1 (legajos) y fila (pos)
docente1=CALIFICACIONES(pos1,1);
fprintf("2.1) La mejor nota de Trato con alumnos es %d y corresponde al docente de legajo %d.\n\n",mejorTrato,docente1);


%Extraigo las notas de "Claridad" (columna 3)
notasClaridad=CALIFICACIONES(:,3);
%Extraigo la mejor nota y la posicion
[mejorClaridad,pos2]=max(notasClaridad);
% Para saber cual es el docente, me fijo en la Matriz calificaciones, columna 1 (legajos) y fila (pos)
docente2=CALIFICACIONES(pos2,1);
fprintf("2.2) La mejor nota de Claridad es %d y corresponde al docente de legajo %d.\n\n",mejorClaridad,docente2);


%Extraigo las notas de "Seguimientos de programa" (columna 4)
notasSeguimiento=CALIFICACIONES(:,4);
%Extraigo la mejor nota y la posicion
[mejorSeguimiento,pos3]=max(notasSeguimiento);
% Para saber cual es el docente, me fijo en la Matriz calificaciones, columna 1 (legajos) y fila (pos)
docente3=CALIFICACIONES(pos3,1);
fprintf("2.3) La mejor nota de Seguimiento es %d y corresponde al docente de legajo %d.\n\n",mejorSeguimiento,docente3);


%Extraigo las notas de "Disponibilidad de consulta" (columna 5)
notasConsulta=CALIFICACIONES(:,5);
%Extraigo la mejor nota y la posicion
[mejorDisponibilidad,pos4]=max(notasConsulta);
% Para saber cual es el docente, me fijo en la Matriz calificaciones, columna 1 (legajos) y fila (pos)
docente4=CALIFICACIONES(pos4,1);
fprintf("2.4) La mejor nota de Disponibilidad para consultas es %d y corresponde al docente de legajo %d.\n\n",mejorDisponibilidad,docente4);


%Extraigo las notas de "Revision de examenes" (columna 6)
notasRevision=CALIFICACIONES(:,6);
%Extraigo la mejor nota y la posicion
[mejorRevision,pos5]=max(notasRevision);
% Para saber cual es el docente, me fijo en la Matriz calificaciones, columna 1 (legajos) y fila (pos)
docente5=CALIFICACIONES(pos5,1);
fprintf("2.5) La mejor nota de Revision de examenes es %d y corresponde al docente de legajo %d.\n\n",mejorRevision,docente5);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% 3) Listar docente, notas (ordenadas de forma decreciente) y promedio

fprintf('\n\n 3) Listo los docentes, sus notas y su promedio\n\n ');
listarYordenar(CALIFICACIONES,promedioNotas,m);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% 4) Listar docente con promedio inferior al promedio general

fprintf('\n\n 4) Listo los docentes, y su promedio (los que estan por debajo del promedio)\n\n ');
listarPromedioInferior(CALIFICACIONES,promedioNotas,m);













