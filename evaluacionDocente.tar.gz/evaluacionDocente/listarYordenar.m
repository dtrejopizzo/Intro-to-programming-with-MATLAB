function listarYordenar(CALIFICACIONES,promedioNotas,m)

for i=1:m
	docente=CALIFICACIONES(i,1);
	nota1=CALIFICACIONES(i,2);
	nota2=CALIFICACIONES(i,3);
	nota3=CALIFICACIONES(i,4);
	nota4=CALIFICACIONES(i,5);
	nota5=CALIFICACIONES(i,6);
	promedioNotasDocente=promedioNotas(i);
	fprintf('Docente: %d	Promedio de sus notas: %.2f \n',docente,promedioNotasDocente);
	fprintf('Trato: %d Claridad: %d Seguimiento: %d Consultas: %d Revision de examenes: %d\n\n',nota1,nota2,nota3,nota4,nota5);
end
