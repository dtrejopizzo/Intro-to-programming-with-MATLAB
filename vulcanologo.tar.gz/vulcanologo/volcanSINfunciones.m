% PROGRAMA PRINCIPAL
clear all
clc
format short g

temp1=0;
temp2=0;
temp3=0;
temp4=0;
temp5=0;
temp6=0;

%Cargar
n=30;
for i=1:n
volcanTemp(i,1)= randi([5 130]);
volcanTemp(i,2)= randi([5 130]);
volcanTemp(i,3)= randi([5 130]);
volcanTemp(i,4)= randi([5 130]);
volcanTemp(i,5)= randi([5 130]);
volcanTemp(i,6)= randi([5 130]);
end

%Buscar temperatura mas alta por lugar

%max1=max(volcanTemp(i,1));
%max2=max(volcanTemp(:,2));
%max3=max(volcanTemp(:,3));
%max4=max(volcanTemp(:,4));
%max5=max(volcanTemp(:,5));
%max6=max(volcanTemp(:,6));

maxVolcan=max(volcanTemp);

%Ordenar de forma decreciente el promedio de temperaturas

for i=1:n
  temp1=temp1+volcanTemp(i,1);
  temp2=temp2+volcanTemp(i,2);
  temp3=temp3+volcanTemp(i,3);
  temp4=temp4+volcanTemp(i,4);
  temp5=temp5+volcanTemp(i,5);
  temp6=temp6+volcanTemp(i,6);
end

tempTotales=[temp1 temp2 temp3 temp4 temp5 temp6];
promTemp=tempTotales/n;

for i=1:6
  tempLugares(i,1)=i;
  tempLugares(i,2)=promTemp(i);
end

%Ordenar la temperatura

for j = 1 : 6
    for k = j + 1 : 6
      if tempLugares(j,2) < tempLugares(k,2);
        aux = tempLugares(j,:);
        tempLugares(j,:) = tempLugares(k,:);
        tempLugares(k,:) = aux;
      end
    end
  end
