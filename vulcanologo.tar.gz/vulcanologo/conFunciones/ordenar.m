function [tempTotales,promTemp,tempLugares]=ordenar(volcanTemp,n)

temp1=0;
temp2=0;
temp3=0;
temp4=0;
temp5=0;
temp6=0;

for i=1:n
  temp1=temp1+volcanTemp(i,1);
  temp2=temp2+volcanTemp(i,2);
  temp3=temp3+volcanTemp(i,3);
  temp4=temp4+volcanTemp(i,4);
  temp5=temp5+volcanTemp(i,5);
  temp6=temp6+volcanTemp(i,6);
end

tempTotales=[temp1 temp2 temp3 temp4 temp5 temp6];
promTemp=tempTotales/n;

for i=1:6
  tempLugares(i,1)=i;
  tempLugares(i,2)=promTemp(i);
end
