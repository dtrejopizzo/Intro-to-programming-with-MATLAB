function [tempLugares]=ordena2(tempLugares)

for j = 1 : 6
    for k = j + 1 : 6
      if tempLugares(j,2) < tempLugares(k,2);
        aux = tempLugares(j,:);
        tempLugares(j,:) = tempLugares(k,:);
        tempLugares(k,:) = aux;
      end
    end
  end
