function [volcanTemp,n]=cargar

n=30;
for i=1:n
volcanTemp(i,1)= randi([5 130]);
volcanTemp(i,2)= randi([5 130]);
volcanTemp(i,3)= randi([5 130]);
volcanTemp(i,4)= randi([5 130]);
volcanTemp(i,5)= randi([5 130]);
volcanTemp(i,6)= randi([5 130]);
end
