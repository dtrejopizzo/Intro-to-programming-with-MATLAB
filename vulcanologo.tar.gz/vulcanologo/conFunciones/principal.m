% PROGRAMA PRINCIPAL
clear all
clc
format short g

%Cargar
[volcanTemp,n]=cargar;

%Buscar temperatura mas alta por lugar

%max1=max(volcanTemp(i,1));
%max2=max(volcanTemp(:,2));
%max3=max(volcanTemp(:,3));
%max4=max(volcanTemp(:,4));
%max5=max(volcanTemp(:,5));
%max6=max(volcanTemp(:,6));

maxVolcan=max(volcanTemp);

%Ordenar de forma decreciente el promedio de temperaturas
[tempTotales,promTemp,tempLugares]=ordenar(volcanTemp,n);


%Ordenar la temperatura
[tempLugOrdenado]=ordena2(tempLugares);
