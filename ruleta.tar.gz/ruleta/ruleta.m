%Generar dos números aleatorios simulando la tirada de la bola de la ruleta y el número obtenido.
%Con uno de ellos, puede obtener tres valores posibles, correspondiendo ellos, a los colores de la ruleta: 1 - rojo, 2 - negro o 3 - verde, 
%Con el otro, puede obtener los valores 0 al 36
%Se producen 100 “tiradas”, obteniendo en cada una de ellas, el color y el número
%Por fin de proceso, indicar:
%a) Cuántas veces salió un valor de la primera docena (1 al 12)
%b) Cuántas veces salió el cero
%c) Cuántas veces salió el color negro
%d) Porcentaje de veces que salió el color rojo. Mostrar el resultado con 3 decimales.

clear all
clc

docena=0;
ceros=0;
negros=0;
rojos=0;

% GENERO MATRIZ CON 100 TIRADAS
for i=1:1:10
RULETA(i,1)=randi([1 3]); %Genero numeros aleatrios entre 1-3 y los guardo en la columna "1", fila "i".
RULETA(i,2)=randi([0 36]); %Genero numeros aleatrios entre 0-36 y los guardo en la columna "2", final "i".
end

% A) Cuantas veces aparecen numeros mayores o iguales a 1 y menos o iguales a 12 en la tabla
for i=1:1:100
	if(RULETA(i,2)>=1 && RULETA(i,2)<=12)
		docena=docena+1;
	end
end

% B) Cuantas veces aparece el numero 0 en la tabla
for i=1:1:100
	if(RULETA(i,2)==0)
		ceros=ceros+1;
	end
end

% C) Cuantas veces aparece el color negro=2 en la tabla
for i=1:1:100
	if(RULETA(i,1)==2)
		negros=negros+1;
	end
end

% D) Porcentaje de rojos=1 en la tabla
for i=1:1:100
	if(RULETA(i,1)==1)
		rojos=rojos+1;
	end
	porcentajeRojos=rojos/100;
end
