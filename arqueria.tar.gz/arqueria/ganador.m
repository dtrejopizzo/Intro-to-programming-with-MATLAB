function [mayor,tirador]=ganador(resultado)

[mayor,tirador]=max(resultado);
