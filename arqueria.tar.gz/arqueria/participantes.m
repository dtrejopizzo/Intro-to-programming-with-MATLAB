function cantidad=participantes()

%Primero guargo en la variable cantidad el numero de tiradores. Luego,
%uso un while para validad que la cantidad ingresa esta entre [5,10].

cantidad=input('ingrese la cantidad de participantes, entre 5 y hasta 10: ')
while (cantidad<5 || cantidad>10)
cantidad=input('ingresar una cantidad de participantes valida: ')
end