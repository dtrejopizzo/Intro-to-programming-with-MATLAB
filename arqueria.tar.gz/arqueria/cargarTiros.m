function [x,y,distancias,puntaje]=cargarTiros(nroTiradores)

%Primero, cargo en dos mastrices separados las coordenadas de cada tiro para cada
%tirador. Las filas corresponden al tirador y las columnas a los tiros.
for i=1:nroTiradores
x(i,:)=randi([0 99],1,10);
y(i,:)=randi([0 99],1,10);
end

%Ahora, genero una nueva matriz llamada "distancias" donde guardo la distancia al centro
%de cada tiro para jugador. Esto, sacando la raiz cuadrada de la suma de los cuadrados
%de las coordenadas x e y pora cada tiro.

%Finalmente genero otras matriz llamada "puntaje" donde mediante una seria de IF
%anidados voy asignando el puntaje al tiro segun la distancia del centro.
for i=1:nroTiradores
  for j=1:10
    distancias(i,j)=sqrt((x(i,j))^2+(y(i,j))^2);
    if (distancias(i,j)>=0 && distancias(i,j)<=5)
      puntaje(i,j)=100;
    elseif (distancias(i,j)>=6 && distancias(i,j)<=15)
      puntaje(i,j)=75;
    elseif (distancias(i,j)>=16 && distancias(i,j)<=30)
      puntaje(i,j)=50;
    elseif (distancias(i,j)>=31 && distancias(i,j)<=50)
      puntaje(i,j)=25;
    elseif (distancias(i,j)>=51 && distancias(i,j)<=75)
      puntaje(i,j)=10;
    else
      puntaje(i,j)=0;
    end
  end
end