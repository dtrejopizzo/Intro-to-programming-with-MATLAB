%Este es el script principal.

%Limpiar la pantalla y las variables cada vez que ejecuto el programa.
clc
clear all

%Punto 1
nroTiradores=participantes();

%Punto 2
[x,y,distancias,puntaje]=cargarTiros(nroTiradores);

%Punto 3
resultado=puntajeTotal(puntaje,nroTiradores);

%Punto 4
[mayor,tiradorGanador]=ganador(resultado);

%Punto 5
[tiro,tirador]=distMinima(distancias,nroTiradores);

%Punto 6
[tiro,tirador]=masLejano(distancias,nroTiradores);

%Punto 7
grafico(nroTiradores,resultado,tiradorGanador)
