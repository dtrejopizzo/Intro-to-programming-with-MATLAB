function resultado=puntajeTotal(puntaje,nroTiradores)

for i=1:nroTiradores
  resultado(i)=sum(puntaje(i,:));
end