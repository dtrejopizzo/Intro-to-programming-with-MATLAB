function [tiro,tirador]=masLejano(distancias,nroTiradores)

%Primero busco el tiro mas lejano de cada jugador en la matriz "distancias"
%y lo guardo en un vector llamado "lejanos", donde cada posicion
%corresponde al tiro mas lejano de cada jugador.

for i=1:nroTiradores
  lejanos(i)=max(distancias(i,:));
end

%Luego, busco cual de esos tiros es el mas lejano.
[tiro, tirador]=max(lejanos);
