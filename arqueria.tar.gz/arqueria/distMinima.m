function [tiro,tirador]=distMinima(distancias,nroTiradores)

%Primero busco el tiro mas cerano de cada jugador en la matriz "distancias"
%y lo guardo en un vector llamado "minimos", donde cada posicion
%corresponde al tiro mas cercano de cada jugador.

for i=1:nroTiradores
  minimos(i)=min(distancias(i,:));
end

%Luego, busco cual de esos tiros es el mas cercano al centro.
[tiro, tirador]=min(minimos);
