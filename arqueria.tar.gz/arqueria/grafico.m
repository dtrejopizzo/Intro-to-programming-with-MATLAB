function grafico(nroTiradores,resultado,tiradorGanador)

plot(resultado,'.g',tiradorGanador,resultado(tiradorGanador),'*r');

title('Primer competencia de IAP de arqueria');
xlabel('Tiradores');
ylabel('Puntaje total');
grid('on');

